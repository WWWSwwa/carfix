/**
 * Theme functions file.
 *
 * Contains handlers for navigation and widget area.
 */

jQuery(window).scroll(function() {
  var data_sticky = jQuery('.menubar').attr('data-sticky');

  if (data_sticky == "true") {
    if (jQuery(this).scrollTop() > 1){
      jQuery('.menubar').addClass("stick_head");
    } else {
      jQuery('.menubar').removeClass("stick_head");
    }
  }
});
