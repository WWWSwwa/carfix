<?php

	

	$automobile_hub_tp_theme_css = '';

	$automobile_hub_tp_color_option = get_theme_mod('automobile_hub_tp_color_option');

if($automobile_hub_tp_color_option != false){
$automobile_hub_tp_theme_css .='button[type="submit"],.top-header,.main-navigation .menu > ul > li.highlight,.box:before,.box:after,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.page-numbers,.prev.page-numbers,.next.page-numbers,span.meta-nav,#theme-sidebar button[type="submit"],#footer button[type="submit"],#comments input[type="submit"],.site-info,.book-tkt-btn a.register-btn,#slider .carousel-control-prev-icon, #slider .carousel-control-next-icon,  .more-btn i , span.cart-value.simplep , .contact-box input[type="text"], .contact-box input[type="email"], .contact-box input[type="phno"], .contact-box input[type="password"], .contact-box textarea, .more-btn a ,.error-404 [type="submit"],.headerbox,.wc-block-cart__submit-container a,.wc-block-checkout__actions_row .wc-block-components-checkout-place-order-button ,.woocommerce ul.products li.product .onsale, .woocommerce span.onsale,nav.woocommerce-MyAccount-navigation ul li:hover,#theme-sidebar .wp-block-search .wp-block-search__label:before, #theme-sidebar h3:before, #theme-sidebar h1.wp-block-heading:before, #theme-sidebar h2.wp-block-heading:before, #theme-sidebar h3.wp-block-heading:before, #theme-sidebar h4.wp-block-heading:before, #theme-sidebar h5.wp-block-heading:before, #theme-sidebar h6.wp-block-heading:before,.wp-block-woocommerce-cart .wp-block-button .wp-block-button__link {';
$automobile_hub_tp_theme_css .='background: '.esc_attr($automobile_hub_tp_color_option).';';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_color_option != false){
$automobile_hub_tp_theme_css .='a,#theme-sidebar .textwidget a,#footer .textwidget a,.comment-body a,.entry-content a,.entry-summary a,.page-template-front-page .media-links a:hover,.topbar-home i.fas.fa-phone-volume,#theme-sidebar h3, .woocommerce-message::before, p.infotext, #about h3 , .search-box i , .page-box h4 a, .readmore-btn a, .headerbox i , #about p i, #theme-sidebar button[type="submit"]:hover, #theme-sidebar h1.wp-block-heading, #theme-sidebar h2.wp-block-heading, #theme-sidebar h3.wp-block-heading,#theme-sidebar h4.wp-block-heading, #theme-sidebar h5.wp-block-heading, #theme-sidebar h6.wp-block-heading,.wp-block-search .wp-block-search__label,.box-info i,a.added_to_cart.wc-forward,#theme-sidebar .wp-block-search .wp-block-search__label, .main-navigation a:hover{';
$automobile_hub_tp_theme_css .='color: '.esc_attr($automobile_hub_tp_color_option).';';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_color_option != false){
$automobile_hub_tp_theme_css .='.woocommerce-message {';
$automobile_hub_tp_theme_css .='border-top-color: '.esc_attr($automobile_hub_tp_color_option).';';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_color_option != false){
$automobile_hub_tp_theme_css .='.readmore-btn a{';
$automobile_hub_tp_theme_css .='border-color: '.esc_attr($automobile_hub_tp_color_option).';';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_color_option != false){
$automobile_hub_tp_theme_css .=' .page-box,#theme-sidebar section{';
$automobile_hub_tp_theme_css .='border-bottom-color: '.esc_attr($automobile_hub_tp_color_option).';';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_color_option != false){
$automobile_hub_tp_theme_css .=' .page-box,#theme-sidebar section {';
$automobile_hub_tp_theme_css .='border-left-color: '.esc_attr($automobile_hub_tp_color_option).';';
$automobile_hub_tp_theme_css .='}';
}

//hover color
$automobile_hub_tp_color_option_link = get_theme_mod('automobile_hub_tp_color_option_link');

if($automobile_hub_tp_color_option_link != false){
$automobile_hub_tp_theme_css .='.prev.page-numbers:focus, .prev.page-numbers:hover, .next.page-numbers:focus, .next.page-numbers:hover,#slider .carousel-control-prev-icon:hover, #slider .carousel-control-next-icon:hover,span.meta-nav:hover, #comments input[type="submit"]:hover,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, #footer button[type="submit"]:hover,#theme-sidebar .tagcloud a:hover, #theme-sidebar button[type="submit"]:hover,.book-tkt-btn a.register-btn:hover,.book-tkt-btn a.bar-btn i:hover, .more-btn a:hover,.wc-block-cart__submit-container a:hover,a.added_to_cart.wc-forward:hover{';
$automobile_hub_tp_theme_css .='background: '.esc_attr($automobile_hub_tp_color_option_link).';';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_color_option_link != false){
$automobile_hub_tp_theme_css .='a:hover,#theme-sidebar a:hover,.media-links i:hover , .headerbox i:hover, a.page-numbers:hover, .post_tag a:hover,#theme-sidebar .widget_tag_cloud a:hover,#footer .tagcloud a:hover,#footer li a:hover {';
$automobile_hub_tp_theme_css .='color: '.esc_attr($automobile_hub_tp_color_option_link).';';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_color_option_link != false){
$automobile_hub_tp_theme_css .='#footer .tagcloud a:hover,.post_tag a:hover,#theme-sidebar .widget_tag_cloud a:hover,.readmore-btn a:hover,a.added_to_cart.wc-forward:hover{';
$automobile_hub_tp_theme_css .='border-color: '.esc_attr($automobile_hub_tp_color_option_link).';';
$automobile_hub_tp_theme_css .='}';
}

if($automobile_hub_tp_color_option_link != false){
$automobile_hub_tp_theme_css .='.woocommerce a.button:hover{';
$automobile_hub_tp_theme_css .='border-color: '.esc_attr($automobile_hub_tp_color_option_link).';';
$automobile_hub_tp_theme_css .='}';
}

$automobile_hub_tp_preloader_color1_option = get_theme_mod('automobile_hub_tp_preloader_color1_option');

if($automobile_hub_tp_preloader_color1_option != false){
$automobile_hub_tp_theme_css .='.center1{';
	$automobile_hub_tp_theme_css .='border-color: '.esc_attr($automobile_hub_tp_preloader_color1_option).' !important;';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_preloader_color1_option != false){
$automobile_hub_tp_theme_css .='.center1 .ring::before{';
	$automobile_hub_tp_theme_css .='background: '.esc_attr($automobile_hub_tp_preloader_color1_option).' !important;';
$automobile_hub_tp_theme_css .='}';
}

$automobile_hub_tp_preloader_color2_option = get_theme_mod('automobile_hub_tp_preloader_color2_option');

if($automobile_hub_tp_preloader_color2_option != false){
$automobile_hub_tp_theme_css .='.center2{';
	$automobile_hub_tp_theme_css .='border-color: '.esc_attr($automobile_hub_tp_preloader_color2_option).' !important;';
$automobile_hub_tp_theme_css .='}';
}
if($automobile_hub_tp_preloader_color2_option != false){
$automobile_hub_tp_theme_css .='.center2 .ring::before{';
	$automobile_hub_tp_theme_css .='background: '.esc_attr($automobile_hub_tp_preloader_color2_option).' !important;';
$automobile_hub_tp_theme_css .='}';
}

$automobile_hub_tp_preloader_bg_color_option = get_theme_mod('automobile_hub_tp_preloader_bg_color_option');

if($automobile_hub_tp_preloader_bg_color_option != false){
$automobile_hub_tp_theme_css .='.loader{';
	$automobile_hub_tp_theme_css .='background: '.esc_attr($automobile_hub_tp_preloader_bg_color_option).';';
$automobile_hub_tp_theme_css .='}';
}

$automobile_hub_tp_footer_bg_color_option = get_theme_mod('automobile_hub_tp_footer_bg_color_option');


if($automobile_hub_tp_footer_bg_color_option != false){
$automobile_hub_tp_theme_css .='#footer{';
	$automobile_hub_tp_theme_css .='background: '.esc_attr($automobile_hub_tp_footer_bg_color_option).';';
$automobile_hub_tp_theme_css .='}';
}

$automobile_hub_footer_widget_image = get_theme_mod('automobile_hub_footer_widget_image');
if($automobile_hub_footer_widget_image != false){
$automobile_hub_tp_theme_css .='#footer{';
$automobile_hub_tp_theme_css .='background: url('.esc_attr($automobile_hub_footer_widget_image).');';
$automobile_hub_tp_theme_css .='}';
}

//======================= slider Content layout ===================== //

$automobile_hub_slider_content_layout = get_theme_mod('automobile_hub_slider_content_layout', 'LEFT-ALIGN'); 
$automobile_hub_tp_theme_css .= '#slider .carousel-caption{';
switch ($automobile_hub_slider_content_layout) {
    case 'LEFT-ALIGN':
        $automobile_hub_tp_theme_css .= 'text-align:left; right: 50%; left: 15%';
        break;
    case 'CENTER-ALIGN':
        $automobile_hub_tp_theme_css .= 'text-align:center; left: 20%; right: 20%';
        break;
    case 'RIGHT-ALIGN':
        $automobile_hub_tp_theme_css .= 'text-align:right; left: 50%; right: 15%';
        break;
    default:
        $automobile_hub_tp_theme_css .= 'text-align:left; right: 50%; left: 15%';
        break;
}
$automobile_hub_tp_theme_css .= '}';


//Font Weight
$automobile_hub_menu_font_weight = get_theme_mod( 'automobile_hub_menu_font_weight','400');
if($automobile_hub_menu_font_weight == '100'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 100;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '200'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 200;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '300'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 300;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '400'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 400;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '500'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 500;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '600'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 600;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '700'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 700;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '800'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 800;';
$automobile_hub_tp_theme_css .='}';
}else if($automobile_hub_menu_font_weight == '900'){
$automobile_hub_tp_theme_css .='.main-navigation a{';
    $automobile_hub_tp_theme_css .='font-weight: 900;';
$automobile_hub_tp_theme_css .='}';
}